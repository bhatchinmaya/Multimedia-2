% Description: plot contour signal n
% 
% Author: Peter Hosten

function plot_n(n)
stem(n)
title('contour signal n')