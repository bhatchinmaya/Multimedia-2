% Description: plot contour signal m
% 
% Author: Peter Hosten


function plot_m(m)
stem(m)
title('contour signal m')