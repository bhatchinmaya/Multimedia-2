function [m,n] = getContourSignals(contur_image, StartPoint_m, StartPoint_n)
    % YOUR TURN
end