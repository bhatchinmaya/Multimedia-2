% Description: Definition of gradient operation to be performed on input
% image. Returned image contains edges found by gradient analysis


function [ output_image ] = gradientAnalysis( input_image, direction )

    % definition of gradient operation
    Gv = %YOUR TURN;
    Gh = %YOUR TURN;
    Gd_plus = %YOUR TURN;

    Gd_minus = %YOUR TURN;
    
    % definition of low-pass filtering
    Mv = %YOUR TURN;
    Mh = %YOUR TURN;
    Md_plus = %YOUR TURN;
    Md_minus = %YOUR TURN;
    
    % now generate filter kernels
    Kv          = %YOUR TURN;
    Kh          = %YOUR TURN; 
    Kd_plus     = %YOUR TURN;
    Kd_minus    = %YOUR TURN;
    
    % apply filter kernel according to direction switch    
    if strcmp(direction, 'v')
        output_image = %YOUR TURN;
    elseif strcmp(direction, 'h')
        output_image = %YOUR TURN;
    elseif strcmp(direction, 'd+')
        output_image = %YOUR TURN;
    elseif strcmp(direction, 'd-')
        output_image = %YOUR TURN;
    end

end

