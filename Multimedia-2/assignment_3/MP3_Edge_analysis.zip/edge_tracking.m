function [tracked_image] = edge_tracking(edge_image, upperth, lowerth)

% initialize output with zeros
tracked_image = zeros(size(edge_image));

extendedImage = padarray(edge_image, [1 1]);


% YOUR TURN - implement the tracking algorithm


% label all edges
tracked_image = bwlabel(tracked_image,8);
end