% Calculate the ray spectra for the given image
function [spectra] = ray_powerspectra(image)

N  = size(image,2); % number of pixel in x-direction
M  = size(image,1); % number of pixel in y-direction

NFFTx = 2^nextpow2(N);  % number of FFT coefficients in x-direction
NFFTy = 2^nextpow2(M);  % number of FFT coefficients in y-direction

complex_spec = fftshift(fft2(image, NFFTy, NFFTx))/sqrt(NFFTy * NFFTx);
powersp = complex_spec.*conj(complex_spec);

% 1000 theta values from 0 to 2pi
thetaValues=linspace(0,2*pi,1000);
% 1000 spectra values. One for every theta value (ray)
spectra=zeros(1000,1);
% 1000 roh values from 0.05 to 0.95
rohValues = linspace(0.05,0.95,1000);

% For every theta value (ray)
for theta_idx=1:1000
    theta = thetaValues( theta_idx );
    
    % Sum over all rho values (sum over the ray given by theta)
    raySum = 0;
    
    % Your turn
    % ---------------
    % Implement the sum over the ray. 
    % All rho values are in rohValues.
    % You then have to calculate the correct cartesian coordinates for
    % rho and theta and get the power spectra value from powersp.
    % Note that the conversion from polar to scalar coordinates will
    % result in values for x and y being in the range of 0...1.
    % The indexes of the values in powersp however are in the range
    % 0...NFFTx and 0...NFFTy respectively, with the center at
    % (NFFTx/2,NFFTy/2). Also the indexes have to be rounded to integer
    % values.
    
    spectra(theta_idx) = raySum;
end

% Normalize and return
spectra = spectra/sum(spectra);