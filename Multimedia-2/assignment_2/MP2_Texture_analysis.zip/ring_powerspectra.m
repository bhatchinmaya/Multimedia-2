% Calculate the ring spectra for the given image
function [spectra] = ring_powerspectra(image)

N  = size(image,2); % number of pixel in x-direction
M  = size(image,1); % number of pixel in y-direction

NFFTx = 2^nextpow2(N);  % number of FFT coefficients in x-direction
NFFTy = 2^nextpow2(M);  % number of FFT coefficients in y-direction

complex_spec = fftshift(fft2(image, NFFTy, NFFTx))/sqrt(NFFTy * NFFTx);
powersp = complex_spec.*conj(complex_spec);

% 1000 roh values from 0.05 to 0.95
rohValues = linspace(0.05,0.95,1000);
% 1000 spectra values. One for every roh value (ring)
spectra=zeros(1000,1);
% 1000 theta values from 0 to 2pi
thetaValues=linspace(0,2*pi,1000);

% For every rho value (ring)
for rho_idx=1:1000
    rho = rohValues( rho_idx );
    
    % Sum over all theta values (sum over the ring given by rho)
    SpecSum = 0;
    
    % Your turn
    % ---------------
    % Implement the sum over the ring. 
    % All theta values are in thetaValues.
    % You then have to calculate the correct cartesian coordinates for
    % rho and theta and get the power spectra value from powersp.
    % Note that the conversion from polar to scalar coordinates will
    % result in values for x and y being in the range of 0...1.
    % The indexes of the values in powersp however are in the range
    % 0...NFFTx and 0...NFFTy respectively, with the center at
    % (NFFTx/2,NFFTy/2). Also the indexes have to be rounded to integer
    % values.
    
    spectra(rho_idx) = SpecSum;
end

% Normalize and return
spectra = spectra/sum(spectra);